// Konstanta dan variabel
const API_URL = 'http://127.0.0.1:5000/api/product';  // Fixed API URL
const itemList = document.getElementById('item-list');
const emptyState = document.getElementById('empty-state');
const itemForm = document.getElementById('item-form');
const itemNameInput = document.getElementById('item-name');
const itemStockInput = document.getElementById('item-stock');
const itemPriceInput = document.getElementById('item-price');
const itemCountSpan = document.getElementById('item-count');
const editModal = document.getElementById('edit-modal');
const editForm = document.getElementById('edit-form');
const editItemIdInput = document.getElementById('edit-item-id');
const editItemNameInput = document.getElementById('edit-item-name');
const editItemStockInput = document.getElementById('edit-item-stock');
const editItemPriceInput = document.getElementById('edit-item-price');
const cancelEditButton = document.getElementById('cancel-edit');

let items = [];

// Fungsi untuk menampilkan error
function showError(message) {
    console.error(message);
}

// Mengambil daftar barang dari API
async function fetchItems() {
    try {
        const response = await fetch(API_URL);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        items = await response.json();
        console.log("Fetched items:", items); // ✅ Check if data is assigned
        console.log("Total items:", items.length); // ✅ Ensure it's not empty
        updateItemCount();
        renderItems();
    } catch (error) {
        showError(`Gagal mengambil barang: ${error.message}`);
    }
}


// Menambahkan barang baru
async function addItem(name, stock, price) {
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, stock, price }),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const newItem = await response.json();
        items.push(newItem);
        updateItemCount();
        renderItems();
    } catch (error) {
        showError(`Gagal menambahkan barang: ${error.message}`);
    }
}

// Mengedit barang
async function updateItem(id, name, stock, price) {
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, stock, price }),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const updatedItem = await response.json();
        items = items.map(item => item.id === id ? updatedItem : item);
        renderItems();
        closeEditModal();

        // ✅ Tampilkan popup sukses
        const popup = document.getElementById('success-popup');
        popup.classList.remove('hidden');
        setTimeout(() => {
            popup.classList.add('hidden');
        }, 2000);
    } catch (error) {
        showError(`Gagal memperbarui barang: ${error.message}`);
    }
}


// Menghapus barang
async function deleteItem(id) {
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        items = items.filter(item => item.id !== id);
        updateItemCount();
        renderItems();
    } catch (error) {
        showError(`Gagal menghapus barang: ${error.message}`);
    }
}

// Memperbarui jumlah barang
function updateItemCount() {
    itemCountSpan.textContent = `${items.length} barang`;
}

// Menampilkan daftar barang
function renderItems() {
    if (items.length === 0) {
        emptyState.classList.remove('hidden');
    } else {
        emptyState.classList.add('hidden');
    }

    itemList.innerHTML = '';
    items.forEach(item => {
        const row = document.createElement('tr');
        row.className = 'border-b';

        row.innerHTML = `
            <td class="border px-4 py-2">${item.name}</td>
            <td class="border px-4 py-2">${item.stock}</td>
            <td class="border px-4 py-2">Rp ${item.price}</td>
            <td class="border px-4 py-2 space-x-2">
                <button onclick="openEditModal(${item.id})" class="bg-yellow-400 text-white px-2 py-1 rounded">Edit</button>
                <button onclick="deleteItem(${item.id})" class="bg-red-500 text-white px-2 py-1 rounded">Hapus</button>
            </td>
        `;
        itemList.appendChild(row);
    });
}

// Membuka modal edit
function openEditModal(itemId) {
    const item = items.find(i => i.id === itemId);
    editItemIdInput.value = item.id;
    editItemNameInput.value = item.name;
    editItemStockInput.value = item.stock;
    editItemPriceInput.value = item.price;
    editModal.classList.remove('hidden');
}

// Menutup modal edit
function closeEditModal() {
    editModal.classList.add('hidden');
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    fetchItems();

    itemForm.addEventListener('submit', e => {
        e.preventDefault();
        addItem(
            itemNameInput.value,
            parseInt(itemStockInput.value),
            parseFloat(itemPriceInput.value)
        );
        
        // Kosongkan input setelah submit
        itemNameInput.value = '';
        itemStockInput.value = '';
        itemPriceInput.value = '';
    });

    editForm.addEventListener('submit', e => {
        e.preventDefault();
        updateItem(
            parseInt(editItemIdInput.value),
            editItemNameInput.value,
            parseInt(editItemStockInput.value),
            parseFloat(editItemPriceInput.value)
        );
    });
    

    cancelEditButton.addEventListener('click', closeEditModal);
});
