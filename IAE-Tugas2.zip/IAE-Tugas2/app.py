from flask import Flask, request, jsonify
from flask_restful import Api, Resource, reqparse
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow

# --- Configuration ---
class Config:
    # Connect to MySQL with root user, no password, on localhost port 3308, using database "y"
    SQLALCHEMY_DATABASE_URI = 'mysql+mysqlconnector://root:@localhost:3308/y'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = 'your-secret-key'

# --- Initialize App and Extensions ---
app = Flask(__name__)
app.config.from_object(Config)
CORS(app, resources={r"/*": {"origins": "*"}})
db = SQLAlchemy(app)
ma = Marshmallow(app)
api = Api(app)

# --- Model ---
class Product(db.Model):
    __tablename__ = 'product'  # Explicitly set table name as "product"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    stock = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)

    def __repr__(self):
        return f'<Product {self.name}>'

# --- Schema ---
class ProductSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Product
        load_instance = True

product_schema = ProductSchema()
products_schema = ProductSchema(many=True)

# --- API Resources ---
class ProductListResource(Resource):
    def get(self):
        products = Product.query.all()
        return products_schema.dump(products), 200

    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('name', required=True, help='Name cannot be blank')
        parser.add_argument('stock', type=int, required=True, help='Stock cannot be blank')
        parser.add_argument('price', type=float, required=True, help='Price cannot be blank')
        args = parser.parse_args()
        new_product = Product(name=args['name'], stock=args['stock'], price=args['price'])
        db.session.add(new_product)
        db.session.commit()
        return product_schema.dump(new_product), 201

class ProductResource(Resource):
    def get(self, product_id):
        product = Product.query.get_or_404(product_id)
        return product_schema.dump(product), 200

    def put(self, product_id):
        parser = reqparse.RequestParser()
        parser.add_argument('name', required=True, help='Name cannot be blank')
        parser.add_argument('stock', type=int, required=True, help='Stock cannot be blank')
        parser.add_argument('price', type=float, required=True, help='Price cannot be blank')
        args = parser.parse_args()
        product = Product.query.get_or_404(product_id)
        product.name = args['name']
        product.stock = args['stock']
        product.price = args['price']
        db.session.commit()
        return product_schema.dump(product), 200

    def delete(self, product_id):
        product = Product.query.get_or_404(product_id)
        db.session.delete(product)
        db.session.commit()
        return {'message': 'Product deleted'}, 204

# --- Register Resources ---
api.add_resource(ProductListResource, '/api/product')
api.add_resource(ProductResource, '/api/product/<int:product_id>')

# --- Run App and Create Tables ---
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
